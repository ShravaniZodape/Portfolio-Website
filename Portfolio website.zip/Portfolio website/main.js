function makeResponsive() {
    const width = window.innerWidth;
    
    const navbar = document.querySelector('.navbar');
    const content = document.querySelector('.content');
    
    if (width < 600) {
        // Mobile view
        navbar.style.flexDirection = "column";
        content.style.width = "100%";
    } else {
        // Desktop view
        navbar.style.flexDirection = "row";
        content.style.width = "70%";
    }
}
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('active');
}

// Add event listener to a menu button for mobile navigation
document.querySelector('.menu-button').addEventListener('click', toggleMenu);